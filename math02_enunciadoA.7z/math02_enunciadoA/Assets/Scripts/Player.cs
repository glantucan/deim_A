﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	[SerializeField] private float v;
	[SerializeField] private Transform[] wayPoints;
	// ...

	void Start () {
		
	}

	void Update () {
		
	}

}
